print("Hello UEFI World")
